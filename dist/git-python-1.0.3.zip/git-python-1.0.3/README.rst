git-python
^^^^^^^^^^

combination and simplification of some useful git commands

Usage
*****

1. add and commit

  gp addc -m "message"
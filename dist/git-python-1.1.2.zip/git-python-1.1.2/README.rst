git-python
^^^^^^^^^^

combination and simplification of some useful git commands

Usage
*****
	
1. init a gp repo

  gp init
  
  gp init -d <dir>

2. add and commit

  gp addc -m <message>

3. push as tag

  gp pushc addt -t <tag>

  gp pushc addr -t <tag> -n <name> -r <remote>

  gp pushc pusht -t <tag>